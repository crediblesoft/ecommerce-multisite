<?php
$tablename="order";
$pagename='order.php';
include('connection.php');
	if(isset($_POST['add'])){
	@extract($_POST);
			$product_id=implode(',',$product_id);
			$sale_rate=implode(',',$sale_rate);
			$quantity=implode(',',$quantity);
		//$query="INSERT INTO $tablename SET product_id='".$product_id."',sale_rate='".$sale_rate."',quantity='".$quantity."',customer_id='".$customer_id."',date='".$date."'";
		$query="INSERT INTO `order`(`id`, `product_id`, `sale_rate`, `quantity`, `pack`, `customer_id`, `date`,`discount`,`vat`) VALUES ('','".$product_id."','".$sale_rate."','".$quantity."','".$pack."','".$customer_id."','".$date."','".$discount."','".$vat."')";
		$result=mysql_query($query) or die(mysql_error());
		
		
		$query1="SELECT * FROM `$tablename` order by id desc limit 0,1";
		//echo $query1;exit;
		$result1=mysql_query($query1) or die(mysql_error());
		
		if($result1){
			$data=mysql_fetch_array($result1);
			
			$product_id=explode(',',$data['product_id']);
			$sl_rate=explode(',',$data['sale_rate']);
			$quantity=explode(',',$data['quantity']);
			
			$count=count($product_id);
			$error=array();
			$total_amount=0;
			for($i=0;$i<$count;$i++){
			
				$query2="SELECT * FROM stock_details WHERE product_id='".$product_id[$i]."'";
				$result2=mysql_query($query2) or die(mysql_error());
				$row2=mysql_fetch_array($result2);
				if($row2['quantity'] >= $quantity[$i]){
				
				$stock_quan=$row2['quantity']-$quantity[$i];
				$amount=$sl_rate[$i]*$quantity[$i];
				$total_amount=$total_amount+$amount;
							

							$query4="INSERT INTO `order_details`(`id`, `customer_id`, `order_id`, `product_id`, `sale_rate`, `quantity`, `amount`)
							VALUES ('',".$customer_id.",".$data['id'].",".$product_id[$i].",".$sl_rate[$i].",".$quantity[$i].",".$amount.")";
							
							$result4=mysql_query($query4) or die(mysql_error());
							
							
							$query3="UPDATE stock_details SET quantity='".$stock_quan."' WHERE id='".$row2['id']."'";  
							$result3=mysql_query($query3) or die(mysql_error());
						
				}else{
					array_push($error,$product_id[$i]);
				}		
				
			}
			
			if($result3 && $result4){
				$query5="INSERT INTO payment SET customer_id=".$customer_id.",order_id=".$data['id'].",amount=".$total_amount.",type='C',type2='S',date=".$date;
				$result5=mysql_query($query5) or die(mysql_error());
			}
			
		}
		
		if($result){
			$abc=implode(' and ',$error);
			$_SESSION['message']=$abc." product are out of stock";
			header("Location:$pagename");
		}
	}
	
	if(isset($_GET['id'])){
		$query="SELECT * FROM $tablename WHERE id=".$_GET['id'];
		$result=mysql_query($query) or die(mysql_error());
		$editdata=mysql_fetch_array($result);
		@extract($editdata);
	}
	
	if(isset($_REQUEST['update'])){
	@extract($_POST);
	//var_dump($_REQUEST);exit;
		$query="UPDATE $tablename SET product_name='".$product_name."',batch='".$batch."',mfg='".$mfg."' WHERE id=".$id;
		$result=mysql_query($query) or die(mysql_error());
		if($result){
			$_SESSION['message']="Update stock Scussesfully!!!";
			header("Location:$pagename");
		}
	}
	
?>
<html>
<head>
<title>:: Billing ::</title>
<link rel="stylesheet" type="text/css" href="style.css" />

<SCRIPT language="javascript">
        function addRow(tableID) {
 
            var table = document.getElementById(tableID);
 
            var rowCount = table.rows.length;
            var row = table.insertRow(rowCount);
 //alert(rowCount);
            var colCount = table.rows[0].cells.length;
 
            for(var i=0; i<colCount; i++) {
 //alert(i);
                var newcell = row.insertCell(i);
 
                newcell.innerHTML = table.rows[0].cells[i].innerHTML;
                //alert(newcell.childNodes[1].id);
                switch(newcell.childNodes[0].type) {
                    case "text":
                            newcell.childNodes[0].value = "";
							if(i==1){
							newcell.childNodes[0].id = "sale_rate"+rowCount;
							}else if(i==2){
							newcell.childNodes[0].id = "quantity"+rowCount;
							}else if(i==3){
							newcell.childNodes[0].id = "avai"+rowCount;
							}
                            break;
                    case "checkbox":
                            newcell.childNodes[0].checked = false;
                            break;
                    case "select-one":
                            newcell.childNodes[0].selectedIndex = 0;
                            break;
					default :
						newcell.childNodes[1].id = rowCount;
                }
            }
        }
 
        function deleteRow(tableID) {
            try {
            var table = document.getElementById(tableID);
            var rowCount = table.rows.length;
 
            for(var i=0; i<rowCount; i++) {
                var row = table.rows[i];
                var chkbox = row.cells[0].childNodes[0];
                if(null != chkbox && true == chkbox.checked) {
                    if(rowCount <= 1) {
                        alert("Cannot delete all the rows.");
                        break;
                    }
                    table.deleteRow(i);
                    rowCount--;
                    i--;
                }
 
 
            }
            }catch(e) {
                alert(e);
            }
        }
 
 
 
 function ProductList(val,id){

	var xmlhttp;
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	  if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
		//alert('response');
	    //alert(xmlhttp.responseText);
		var data=xmlhttp.responseText;
		var abc=data.split("|");
		//alert(abc[0]);
		document.getElementById("sale_rate"+id).value=abc[0];
		document.getElementById("avai"+id).value=abc[1];
		// alert("Status is : " + xmlhttp.responseText);
		}
	  }

	xmlhttp.open("GET","show_price.php?pro_id="+val,true);
xmlhttp.send();
 }
    </SCRIPT>

</head>
<body>
	<div id='container'>
	<div id='header'>
		<?php include("header.php");?>
     </div>
     <div id='content'>	
	 <div class='title'> <a href='<?php echo $pagename;?>'>Manage Order</a></div>
	 <div class='line'></div>
		<div id='form1'>
		<?php if(isset($_GET['id'])){ ?>
		<form name='product' action='#' method='post'>
		<input type='hidden' name='id' id='id' value='<?php echo $id; ?>'>
			<table class="pro" width="100%">
				<tr>
				<td class='message'><?php if(isset($_SESSION['message'])){ 
						 echo $_SESSION['message'];
					     //unset($_SESSION['message']);
				} ?></td>
				</tr>
				<tr>
				<td>Select Customer</td>
				<td>
				<?php 
						$query="SELECT * FROM customer";
						$result=mysql_query($query) or die(mysql_error());
					?>
					<select name='product_id' class='select_box'>
						<option value=''>---Please Select---</option>
						<?php while($row=mysql_fetch_array($result)){ ?>
						<option value='<?php echo $row['id']; ?>'><?php echo $row['customer_name']; ?></option>
						<?php } ?>
					</select>
				
				</td>
				</tr>
				<tr>
				<th>Select Product</th>
				<th>Sale Rate</th>
				<th>Quantity</th>
				</tr>
				<tr>
				<td>
					<?php 
						$query="SELECT * FROM product";
						$result=mysql_query($query) or die(mysql_error());
					?>
					<select name='product_id' class='select_box'>
						<option value=''>---Please Select---</option>
						<?php while($row=mysql_fetch_array($result)){ ?>
						<option value='<?php echo $row['id']; ?>'><?php echo $row['product_name']; ?></option>
						<?php } ?>
					</select>
				</td>
				<td><input type='text' name='sl_rate' id='sale_rate' class='textbox'></td>
				<td><input type='text' name='quantity' id='quantity' class='textbox'></td>
				</tr>
				<tr>
				<td colspan='2' align='center'><input type='submit' name='update' value='Update' id='submit' class='submit'></td>
				</tr>
			</table>
		</form>
		
		<?php }else{ ?>
		<form name='stock' action='#' method='post'>
			<table class="pro" width="100%">
				<tr>
				<td class='message'><?php if(isset($_SESSION['message'])){ 
						 echo $_SESSION['message'];
					     //unset($_SESSION['message']);
				} ?></td>
				</tr>
				<tr>
                    <td style="color:#333">Select Customer</td>
                    <td>
                    <?php 
                            $query="SELECT * FROM customer";
                            $result=mysql_query($query) or die(mysql_error());
                        ?>
                        <select name='customer_id' class='select_box'>
                            <option value=''>---Please Select---</option>
                            <?php while($row=mysql_fetch_array($result)){ ?>
                            <option value='<?php echo $row['id']; ?>'><?php echo $row['customer_name']; ?></option>
                            <?php } ?>
                        </select>
                    
                    </td>
                    <td colspan="2">&nbsp;</td>
                    <td style="color:#333">Date</td>
                    <td> <input type='text' name='date' value="<?php echo date("d-m-Y");?>" id='date' class='textbox'>  </td>
				</tr>

				<tr>
				<td style="color:#333">Select Product</td>
                    <td>
                        <?php 
                            $query="SELECT * FROM product";
                            $result=mysql_query($query) or die(mysql_error());
                        ?>
                        <select type='select-one' class='select_box' name='product_id[]' id='0' onChange="ProductList(this.value,this.id);">
                            <option value=''>---Please Select---</option>
                            <?php while($row=mysql_fetch_array($result)){ ?>
                            <option value='<?php echo $row['id']; ?>'><?php echo $row['product_name']; ?></option>
                            <?php } ?>
                        </select>
                    </td>
                </tr>

                <tr>
				<td style="color:#333">Available Quantity</td>
                    <td><input type='text' name='availablequan[]' id='avai0' class='textbox' readonly ></td>
                </tr>

                <tr>
				<td style="color:#333">Sale Rate</td>
                    <td><input type='text' name='sale_rate[]' id='sale_rate0' class='textbox' readonly></td>
                </tr>

                <tr>
				<td style="color:#333">Pack Quantity</td>
                    <td><input type='text' name='pack' id='pack' class='textbox'></td>
                </tr>

                <tr>
				<td style="color:#333">Order Quantity</td>
                    <td><input type='text' name='quantity[]' id='quantity0' class='textbox'></td>
                </tr>

                <tr>
				<td style="color:#333">Discount (%)</td>
                    <td > <input type='text' name='discount' id='discount' class='textbox'>  </td>
                </tr>

                <tr>
				<td style="color:#333">VAT (%)</td>
                    <td > <input type='text' name='vat' id='vat' class='textbox'>  </td>
				</tr>	

				<tr>
				<td colspan='5' align='center'><input type='submit' name='add' value='Save' id='submit' class='submit'></td>
				</tr>
			</table>
			<input type="button" value="Add Row" onClick="addRow('dataTable')" />
		</form>
		<?php } ?>
		</div>
		
     </div>	
	 <div id='footer'>	
     </div>
	 </div>
</body>
</html>