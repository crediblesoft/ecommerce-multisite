<?php
$tablename="tax";
$pagename='tax.php';
include('connection.php');
	if(isset($_REQUEST['add'])){
	@extract($_POST);
	//var_dump($_REQUEST);exit;
		$query="INSERT INTO $tablename SET vat='".$vat."', dis='".$dis."'";
		$result=mysql_query($query) or die(mysql_error());
		if($result){
			$_SESSION['message']="Add Tax Successfully!!!";
			header("Location:$pagename");
		}
	}
	
	if(isset($_GET['id'])){
		$query="SELECT * FROM $tablename WHERE id=".$_GET['id'];
		$result=mysql_query($query) or die(mysql_error());
		$editdata=mysql_fetch_array($result);
		@extract($editdata);
	}

	if(isset($_REQUEST['update'])){
	@extract($_POST);
	//var_dump($_REQUEST);exit;
		$query="UPDATE $tablename SET vat='".$vat."', dis='".$dis."' WHERE id=".$id;
		$result=mysql_query($query) or die(mysql_error());
		if($result){
			$_SESSION['message']="Update Customer Scussesfully!!!";
			header("Location:$pagename");
		}
	}

	
	$pagesize=20;
	$query="select count(*) from $tablename";
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	$count=$row[0];
	$page=ceil($count/$pagesize);
	
	if(isset($_GET['page'])){
		$from=($_GET['page']-1)*$pagesize;
		$query="SELECT * FROM $tablename Limit $from,$pagesize";
	}else{
		$query="SELECT * FROM $tablename Limit 0,$pagesize";
	}
		$data=mysql_query($query);
?>
<html>
<head>
<title>:: Billing ::</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
	<div id='container'>
	<div id='header'>
		<?php include("header.php");?>
     </div>
     <div id='content'>	
	 <div class='title'> <a href='<?php echo $pagename;?>'>Manage Product</a></div>
	 <div class='line'></div>
		<div id='form'>
		<?php if(isset($_GET['id'])){ ?>
		<form name='product' action='#' method='post'>
		<input type='hidden' name='id' id='id' value='<?php echo $id; ?>'>
			<table>
				<tr>
				<td class='message'><?php if(isset($_SESSION['message'])){ 
						 echo $_SESSION['message'];
					     //unset($_SESSION['message']);
				} ?></td>
				</tr>
				<tr>
				<td class='form_td'>Vat</td>
				<td><input type='text' name='vat' id='vat' class='textbox' value='<?php echo $vat; ?>'></td>
				</tr>
				<tr>
				<td class='form_td'>Discount</td>
				<td><input type='text' name='dis' id='dis' class='textbox' value='<?php echo $dis; ?>'></td>
				</tr>
				
				<tr>
				<td colspan='2' align='center'><input type='submit' name='update' value='Update' id='submit' class='submit'></td>
				</tr>
			</table>
		</form>
		
		<?php }else{ ?>
		<form name='product' action='#' method='post'>
			<table>
				<tr>
				<td class='message'><?php if(isset($_SESSION['message'])){ 
						 echo $_SESSION['message'];
					     //unset($_SESSION['message']);
				} ?></td>
				</tr>
				<tr>
				<td class='form_td'>Vat</td>
				<td><input type='text' name='vat' id='vat' class='textbox'></td>
				</tr>
				<tr>
				<td class='form_td'>Discount</td>
				<td><input type='text' name='dis' id='dis' class='textbox'></td>
				</tr>
				<tr>
				<td colspan='2' align='center'><input type='submit' name='add' value='Save' id='submit' class='submit'></td>
				</tr>
			</table>
		</form>
		<?php } ?>
		</div>
		<div id='alldata'>
			<form name='data' >
				<table class="pro" width="100%" cellpadding='2' cellspacing='0' border='0'>
					<tr>
						<th width='10%'>S.No</th>
						<th width='30%'>Vat</th>
						<th width='20%'>Discount</th>
						<th width='20%'>&nbsp;</th>
<!--						<th width='30%'><input type='checkbox' ></th>
-->					</tr>
					<?php
						$i=1;
						while($row=mysql_fetch_array($data)){
						@extract($row);
						if($i%2==1){
						   $color='#888';
						}else{
						  $color='#666';
						}
					?>
					<tr bgcolor='<?php echo $color; ?>'>
						<td><?php echo $i; ?></td>
						<td><?php echo $vat; ?></td>
						<td><?php echo $dis; ?></td>
						<td><a href='<?php echo $pagename; ?>?id=<?php echo $id; ?>'> <img src="images/edit_button.png"> </a></td>
<!--						<td><input type='checkbox' name='id[]' value='<?php /*echo $id;*/ ?>' ></td>
-->					</tr>
					<?php $i++; } ?>
					<tr bgcolor='#000'>
						<td colspan='8' align='right' class='pagination'> 
							<?php for($p=1;$p<=$page;$p++){ ?>
								<a href='<?php echo $pagename; ?>?page=<?php echo $p; ?>'> <?php echo $p; ?> </a> 
							<?php } ?> 
						</td>
					</tr>
				</table>
			</form>	
			</div>
     </div>	
	 <div id='footer'>	
     </div>
	 </div>
</body>
</html>