<?php
function productName($id){
	$query="SELECT * FROM product WHERE id=".$id;
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	return $row['product_name'];
}

function productDetails($id){
	$query="SELECT * FROM product WHERE id=".$id;
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	return $row;
}

function customerName($id){
	$query="SELECT * FROM customer WHERE id=".$id;
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	return $row['customer_name'];
}

function customerDetails($id){
	$query="SELECT * FROM customer WHERE id=".$id;
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	return $row;
}

function orderDetails($id){
	$query="SELECT * FROM `order_details` WHERE id=".$id;
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	return $row;
}

function order($id){
	$query="SELECT * FROM `order` WHERE id=".$id;
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	return $row;
}

function tax($id){
	$query="SELECT * FROM `tax` WHERE id=".$id;
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	return $row;
}

function stockDetails($id){
	$query="SELECT * FROM `stock_details` WHERE product_id=".$id;
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	return $row;
}
?>