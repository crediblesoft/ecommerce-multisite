<html>
<head>
<title>:: Billing ::</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
	<div id='container'>
	<div id='header'>
		<?php include("header.php");?>
     </div>
     <div id='content'>	
     </div>	
	 <div id='footer'>	
     </div>
	 </div>
</body>
</html>