<?php
include('connection.php');
$id=$_GET['pro_id'];
	$query="select * from stock_details where product_id=".$id;
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_assoc($result);
	//var_dump($row);
	
	$pro_query="select tax from product where id=".$id;
	$pro_result=mysql_query($pro_query) or die(mysql_error());
	$pro_row=mysql_fetch_array($pro_result);
	
	echo $row['sale_rate'].'|'.$row['quantity'].'|'.$row['pack']."|".$pro_row[0];
?>