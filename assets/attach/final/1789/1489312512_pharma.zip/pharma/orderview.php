<?php 
$tablename="order_details";
$pagename='orderview.php';
include('connection.php');
include('function.php');
	$pagesize=30;
	$query="select count(*),sum(amount) from `$tablename` WHERE order_id=".$_GET['id'];
	$result=mysql_query($query) or die(mysql_error());
	$row1=mysql_fetch_array($result);
	$count=$row1[0];
	$page=ceil($count/$pagesize);
	
	if(isset($_GET['page'])){
		$from=($_GET['page']-1)*$pagesize;
		$query="SELECT * FROM `$tablename` WHERE order_id=".$_GET['id']." Limit $from,$pagesize";
	}else{
		$query="SELECT * FROM `$tablename` WHERE order_id=".$_GET['id']." Limit 0,$pagesize";
	}
		$data=mysql_query($query);

	$orderData=order($_GET['id']);

?>
<html>
<head>
<title>:: Billing ::</title>
 <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
	<div id='container'>
	<div id='header'>
		<?php include("header.php");?>
     </div>
   <div class="heading">	         
             <div><a href='bill.php?id=<?php echo $_GET['id']; ?>' target='_blank'><img src="images/print_button.png"></a></div>
   </div>
     <div id='content'>	
<div id='alldata' style='margin-top:20px;'>
			<form name='data' >
				<table class="pro" width="100%" cellpadding='2' cellspacing='0' border='0'>
					<tr bgcolor='#afafc5'>
						<th width='10%'>S No.</th>
						<th width='30%' colspan="3">Product Name</th>
						<th width='20%'>Sale Rate</th>
						<th width='20%'>Quantity</th>
						<th width='20%'>Pack</th>
						<th width='20%'>Vat/Discount</th>
						<th width='20%'>Amount</th>
					</tr>
					<?php
						$i=1;
						while($row=mysql_fetch_array($data)){
						@extract($row);
						if($i%2==1){
						   $color='#888';
						}else{
						  $color='#666';
						}
						$tax=tax($tax);
					?>
					<tr bgcolor='<?php echo $color; ?>'>
						<td class='td'><?php echo $i; ?></td>
						<td class='td' colspan='3'><?php echo productName($product_id); ?></td>
						<td class='td'><?php echo $sale_rate; ?></td>
						<td class='td'><?php echo $quantity; ?></td>
						<td class='td'><?php echo $pack; ?></td>
						<td class='td'><?php echo $tax['vat'].'/'.$tax['dis']; ?></td>
						<td class='td'><?php echo $amount; ?></td>
						
					</tr>
					<?php $i++; } ?>
					
					<tr bgcolor='#afafc5'>
						<td  align='right'> Class </td>
						<td  align='right'> Gross Amt </td>
						<td  align='right'> DISC </td>
						<td  align='right'>  SCM </td>
						<td  align='right'>  Taxable</td>
						<td  align='right'>  Vat</td>
						<td  align='right' colspan='3'> Net Amt </td>
					</tr>
<?php
$query="SELECT * FROM `order` where id=".$_GET['id'];
$result=mysql_query($query) or die($query);
$row=mysql_fetch_array($result);
$tax=explode(',',$row['tax']);
$tax1=array_unique($tax);
$finalGT=0;
for($i=0;$i<count($tax1);$i++){
		$query1="select sum(amount) from `$tablename` WHERE order_id=".$_GET['id']." AND tax=".$tax1[$i];
		$result1=mysql_query($query1) or die(mysql_error());
		$row1=mysql_fetch_array($result1);
		
		$orderData=tax($tax1[$i]);
	
	$total = $row1[0];
	$discount=($row1[0]*$orderData['dis'])/100;
	$taxable=$total-$discount;
	$vat=($taxable*$orderData['vat'])/100;
	$grandTotal=$taxable+$vat;
	$finalGT=$finalGT+$grandTotal;
?>
					<tr bgcolor='#afafc5'>
						<td  align='right'> VAT <?php echo $orderData['vat']; ?> %</td>
						<td  align='right'> <?php echo round($total,2); ?> </td>
						<td  align='right'> <?php echo round($discount,2);  ?> </td>
						<td  align='right'>  0.00 </td>
						<td  align='right'> <?php echo round($taxable,2); ?></td>
						<td  align='right'>  <?php echo round($vat,2);?></td>
						<td  align='right' colspan='3'> <?php echo round($grandTotal,2); ?> </td>
					</tr>
<?php } ?>		

			<tr bgcolor='#000'>
						<td colspan='9' align='right'> 
							<?php
								echo round($finalGT,2);
							?>
						</td>
					</tr>		
					<tr bgcolor='#000'>
						<td colspan='9' align='right' class='pagination'> 
							<?php for($p=1;$p<=$page;$p++){ ?>
								<a href='<?php echo $pagename; ?>?page=<?php echo $p; ?>'> <?php echo $p; ?> </a> 
							<?php } ?> 
						</td>
					</tr>
				</table>
			</form>	
			</div>
     </div>	
	 <div id='footer'>	
     </div>
	 </div>
</body>
</html>			