<?php 
$tablename="payment";
$pagename='ledger.php';
include('connection.php');
include('function.php');
$id=$_GET['cus_id'];
if($id==''){
return false;
}
	$pagesize=10;
	$query="select count(*) from $tablename WHERE customer_id=".$customer_id;
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	$count=$row[0];
	$page=ceil($count/$pagesize);
	
	if(isset($_GET['page'])){
		$from=($_GET['page']-1)*$pagesize;
		$query="SELECT * FROM $tablename WHERE customer_id=".$id." Limit $from,$pagesize";
	}else{
		$query="SELECT * FROM $tablename WHERE customer_id=".$id." Limit 0,$pagesize";
	}
		$data=mysql_query($query);
		
		
$cr_query="SELECT sum(amount) FROM payment WHERE customer_id=".$id." AND type2='S'";
$cr_result=mysql_query($cr_query) or die(mysql_error());
$cr_row=mysql_fetch_array($cr_result);

$dr_query="SELECT sum(amount) FROM payment WHERE customer_id=".$id." AND type2='P'";
$dr_result=mysql_query($dr_query) or die(mysql_error());
$dr_row=mysql_fetch_array($dr_result);

if($cr_row[0] > $dr_row[0]){
	$total=$cr_row[0] - $dr_row[0];
	$g_total=$total." Cr.";
}else if($cr_row[0] < $dr_row[0]){
	$total=$dr_row[0] - $cr_row[0];
	$g_total=$total." Dr.";
}else{
	$g_total="NIL";
}
		
?>
<table class="pro" width="100%" cellpadding='2' cellspacing='0' border='0'>
					<tr bgcolor='#afafc5'>
						<th width='10%'>S No.</th>
						<th width='30%'>Customer Name</th>
						<th width='10%'>Cr.(-)</th>
						<th width='10%'>Dr.(+)</th>
						<th width='10%'>Date</th>
						<th width='30%'>Comment</th>
						<!--<th width='30%'>Edit</th>
						<th width='30%'><input type='checkbox' ></th>-->
					</tr>
					<?php
						$i=1;
						while($row=mysql_fetch_array($data)){
						@extract($row);
						if($i%2==1){
						   $color='#888';
						}else{
						  $color='#666';
						}
					?>
					<tr bgcolor='<?php echo $color; ?>'>
						<td class='td'><?php echo $i; ?></td>
						<td class='td'><?php echo customerName($customer_id); ?></td>
						<td class='td'><?php if($type2=='S'){ echo $amount;}  ?></td>
						<td class='td'><?php if($type2=='P'){ echo $amount;} ?></td>
						<td class='td'><?php echo $date; ?></td>
						<td class='td'><?php echo $comment; ?></td>
						<!--<td class='td'><a href='<?php /*echo $pagename; ?>?id=<?php echo $id; ?>'> Edit </a></td>
						<td class='td'><input type='checkbox' name='id[]' value='<?php echo $id;*/ ?>' ></td>-->
					</tr>
					<?php $i++; } ?>
					<tr bgcolor='#afafc5'> 
						<td colspan='2' align='center'> Total </td>
						<td align='center'> <?php echo $cr_row[0]; ?> </td>
						<td align='center'> <?php echo $dr_row[0]; ?> </td>
						<td colspan='2' align='center'> <?php echo $g_total; ?> </td>
					</tr>
					<tr bgcolor='#000'>
						<td colspan='6' align='right' class='pagination'> 
							<?php for($p=1;$p<=$page;$p++){ ?>
								<a href='<?php echo $pagename; ?>?page=<?php echo $p; ?>'> <?php echo $p; ?> </a> 
							<?php } ?> 
						</td>
					</tr>
				</table>