<?php 
$tablename="payment";
$pagename='ledger.php';
include('connection.php');
include('function.php');
	$pagesize=10;
	$query="select count(*) from $tablename";
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	$count=$row[0];
	$page=ceil($count/$pagesize);
	
	if(isset($_GET['page'])){
		$from=($_GET['page']-1)*$pagesize;
		$query="SELECT * FROM $tablename Limit $from,$pagesize";
	}else{
		$query="SELECT * FROM $tablename Limit 0,$pagesize";
	}
		$data=mysql_query($query);
		
		
$cr_query="SELECT sum(amount) FROM payment WHERE type2='S'";
$cr_result=mysql_query($cr_query) or die(mysql_error());
$cr_row=mysql_fetch_array($cr_result);

$dr_query="SELECT sum(amount) FROM payment WHERE type2='P'";
$dr_result=mysql_query($dr_query) or die(mysql_error());
$dr_row=mysql_fetch_array($dr_result);

if($cr_row[0] > $dr_row[0]){
	$total=$cr_row[0] - $dr_row[0];
	$g_total=$total." Cr.";
}else if($cr_row[0] < $dr_row[0]){
	$total=$dr_row[0] - $cr_row[0];
	$g_total=$total." Dr.";
}else{
	$g_total="NIL";
}
		
?>
<html>
<head>
<title>:: Billing ::</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<script language='javascript'>
function ProductList(val){

	var xmlhttp;
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	  if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
		//alert('response');
	    //alert(xmlhttp.responseText);
		if(xmlhttp.responseText!=''){
		document.getElementById('ledger').innerHTML=xmlhttp.responseText;
		}

		}
	  }

	xmlhttp.open("GET","customer_ledger.php?cus_id="+val,true);
xmlhttp.send();
 }
 
 
 function PrintContent()
{
var DocumentContainer = document.getElementById('ledger');
var WindowObject = window.open('', "PrintWindow", "width=750,height=750,top=50,left=50,toolbars=yes,scrollbars=yes,status=no,resizable=yes,border=1px");
WindowObject.document.writeln('<html><head><link rel="stylesheet" type="text/css" href="css/stylesheet.css" /></head><body>');
WindowObject.document.writeln(DocumentContainer.innerHTML);
WindowObject.document.writeln('</body></html>');
WindowObject.document.close();
WindowObject.focus();
WindowObject.print();
WindowObject.close();
}
</script>
</head>
<body>
	<div id='container'>
	<div id='header'>
		<?php include("header.php");?>
     </div>
        <div class="heading">	         
             <div><a  onclick="PrintContent();" href="#" class="button"><img src="images/print_button.png"></a></div>
   </div>

     <div id='content'>	
	 <div class='title'> <a href='<?php echo $pagename;?>'>Manage Ledger</a></div>
	 <div class='line'></div>
<div id='alldata' style='margin-top:20px;'>
					<?php 
						$cus_query="SELECT * FROM customer";
						$cus_result=mysql_query($cus_query) or die(mysql_error());
					?>
					<div>
					<span class='form_td'>Select Customer</span>
					<span>
					<select name='customer_id' id='customer_id' onChange="ProductList(this.value);" class='select_box'>
						<option value=''>---Please Select---</option>
						<?php while($cus_row=mysql_fetch_array($cus_result)){ ?>
						<option value='<?php echo $cus_row['id']; ?>'><?php echo $cus_row['customer_name']; ?></option>
						<?php } ?>
					</select>
					</span><br><br>
					</div>
			<form name='data' id='ledger'>
				<table class="pro" width="100%" cellpadding='2' cellspacing='0' border='0'>
					<tr bgcolor='#afafc5'>
						<th width='10%'>S No.</th>
						<th width='30%'>Customer Name</th>
						<th width='10%'>Cr.(-)</th>
						<th width='10%'>Dr.(+)</th>
						<th width='10%'>Date</th>
						<th width='30%'>Comment</th>
						<!--<th width='30%'>Edit</th>
						<th width='30%'><input type='checkbox' ></th>-->
					</tr>
					<?php
						$i=1;
						while($row=mysql_fetch_array($data)){
						@extract($row);
						if($i%2==1){
						   $color='#888';
						}else{
						  $color='#666';
						}
					?>
					<tr bgcolor='<?php echo $color; ?>'>
						<td class='td'><?php echo $i; ?></td>
						<td class='td'><?php echo customerName($customer_id); ?></td>
						<td class='td'><?php if($type2=='S'){ echo $amount;}  ?></td>
						<td class='td'><?php if($type2=='P'){ echo $amount;} ?></td>
						<td class='td'><?php echo $date; ?></td>
						<td class='td'><?php echo $comment; ?></td>
						<!--<td class='td'><a href='<?php /*echo $pagename; ?>?id=<?php echo $id; ?>'> Edit </a></td>
						<td class='td'><input type='checkbox' name='id[]' value='<?php echo $id;*/ ?>' ></td>-->
					</tr>
					<?php $i++; } ?>
					<tr bgcolor='#afafc5'> 
						<td colspan='3' align='center'> Total </td>
						<td align='center'> <?php echo $cr_row[0]; ?> </td>
						<td align='center'> <?php echo $dr_row[0]; ?> </td>
						<td colspan='2' align='center'> <?php echo $g_total; ?> </td>
					</tr>
					<tr bgcolor='#000'>
						<td colspan='6' align='right' class='pagination'> 
							<?php for($p=1;$p<=$page;$p++){ ?>
								<a href='<?php echo $pagename; ?>?page=<?php echo $p; ?>'> <?php echo $p; ?> </a> 
							<?php } ?> 
						</td>
					</tr>
				</table>
			</form>	
			</div>
     </div>	
	 <div id='footer'>	
     </div>
	 </div>
</body>
</html>			