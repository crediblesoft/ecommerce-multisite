<?php 
$tablename="order_details";
$pagename='orderview.php';
include('connection.php');
include('numtochar.php');
include('function.php');
	$pagesize=30;
	$query="select count(*),sum(amount) from `$tablename` WHERE order_id=".$_GET['id'];
	$result=mysql_query($query) or die(mysql_error());
	$row1=mysql_fetch_array($result);
	$count=$row1[0];
	$page=ceil($count/$pagesize);
	
	if(isset($_GET['page'])){
		$from=($_GET['page']-1)*$pagesize;
		$query="SELECT * FROM `$tablename` WHERE order_id=".$_GET['id']." Limit $from,$pagesize";
	}else{
		$query="SELECT * FROM `$tablename` WHERE order_id=".$_GET['id']." Limit 0,$pagesize";
	}
		$data=mysql_query($query);
	
/* 
$orderData=order($_GET['id']);

	$total = $row1[1];
	$discount=($row1[1]*$orderData['dis'])/100;
	$taxable=$total-$discount;
	$vat=($taxable*$orderData['vat'])/100;
	$grandTotal=$taxable+$vat;	*/
		
		/*$query2 = "SELECT customer.* FROM customer INNER JOIN order_details ON customer.id = order_details.customer_id";
		$result1 = mysql_query($query2);
		$row1 = mysql_fetch_array($result1);*/
		
		$abc=order($_GET['id']);
		$row1=customerDetails($abc['customer_id']);
?>

<script type="text/javascript">
function PrintContent()
{
var DocumentContainer = document.getElementById('bill');
var WindowObject = window.open('', "PrintWindow", "width=750,height=750,top=50,left=50,toolbars=yes,scrollbars=yes,status=no,resizable=yes,border=1px");
WindowObject.document.writeln('<html><head><link rel="stylesheet" type="text/css" href="css/style.css" /></head><body>');
WindowObject.document.writeln(DocumentContainer.innerHTML);
WindowObject.document.writeln('</body></html>');
WindowObject.document.close();
WindowObject.focus();
WindowObject.print();
WindowObject.close();
}


</script>

<html>
<head>
<title>:: Billing ::</title>
<link rel="stylesheet" type="text/css" media="screen, print" href="style.css" />
</head>
<body>
	<div id='container'>
	<div id='header'>
		<?php include("header.php");?>
     </div>
   <div class="heading">	         
             <div><a  onclick="PrintContent();" href="#" class="button"><img src="images/print_button.png"></a></div>
            
   </div>
    <div class="content" id="print">
	<h2 style="margin-top:0px;text-align:center">Bill Details <h4 style="margin-top:-14px;float:right;">Date:<?php echo date("d-m-y H:i:s");?></h4></h2>	
<br/><br/>
<div id="bill">
 
       <h4 align="center"><u>RETAIL INVOICE BILL</u></h4><br>
        
        <table width="100%" style=" border-collapse:collapse; border:1px #333 solid;">
        <tr>
        <td class="com-detail">
            <table width="100%" style="font-size:14px">
                <tr><td><p style="font-size:16px; font-weight:bold; padding:0; margin:0;">ARADHANA PHARMA</p><p style="font-size:9px; padding:0; margin:0">( PHARMACEUTICALS DISTRIBUTORS )</p></td></tr>
                <tr><td>C-14, KH.No.109, Ground Floor, Premnagar-III, <br>Near Durga Chowk, Delhi-110086</td></tr>
                <tr><td><strong>Mobile</strong> : 8802975705, 9958457571</td></tr> 
                <tr><td><strong>DL No.</strong> : NW(1992) W/14 20B &amp; 21B</td></tr>
                <tr><td><strong>TIN No.</strong> : </td></tr>
                <tr><td><strong>Mode of Transport</strong> : Cycle/Auto/..</td></tr>
           </table>
        </td>
        <td class="cust-detail" style="float:right">
            <table width="100%" style="font-size:14px; float:right">
                <tr><td><p style="font-size:14px; font-weight:bold">M/S : <?php echo $row1['customer_name'];?></p> </td></tr>
                <tr><td><?php echo $row1['address'];?></td></tr>
                <tr><td><strong>Mobile</strong> : <?php echo $row1['mobile'];?></td></tr> 
                <tr><td><strong>DL No.</strong> : <?php echo $row1['dl'];?></td></tr>
                <tr><td><strong>TIN No.</strong> : <?php echo $row1['tin'];?></td></tr>
                <tr><td>&nbsp;</td></tr>
                <tr><td><h3>Invoice No. :011<?php echo $_GET['id'];?>&nbsp;&nbsp;&nbsp;&nbsp;Date : <?php echo date("d-m-Y");?></h3></td></tr>
           </table>
        </td>
        </tr>
        </table>
    

    <div class="bill-detail">
         <table style=" border-collapse:collapse; border:1px #333 solid; text-align:center" width="100%" cellspacing='2' cellpadding='3' >
               <tr><td height="10px">&nbsp;</td></tr>
                <tr style="font-size:14px">
                  <th style="border-bottom:#333 dotted 1px;">QTY</th>
                  <th style="border-bottom:#333 dotted 1px;">PACK</th>
                  <th style="border-bottom:#333 dotted 1px;">PRODUCT</th>             
                  <th style="border-bottom:#333 dotted 1px;">MFG/MKT.</th>
                  <th style="border-bottom:#333 dotted 1px;">BATCH</th>
                  <th style="border-bottom:#333 dotted 1px;">EXPIRY</th>
                  <th style="border-bottom:#333 dotted 1px;">VAT%</th>
                  <th style="border-bottom:#333 dotted 1px;">DIS%</th>
                  <th style="border-bottom:#333 dotted 1px;">MRP</th>
                  <th style="border-bottom:#333 dotted 1px;">RATE</th>
                  <th style="border-bottom:#333 dotted 1px;">AMOUNT</th>
                </tr>
              <?php
					$i=1;
					while($row=mysql_fetch_array($data)){
					@extract($row);
					if($i%2==1){
					   $color='#fff';
					}else{
					  $color='#c1ccff';
					}
					
					$productDetails=productDetails($product_id);
					$stockDetails=stockDetails($product_id);
					$tax=tax($tax);
				?>
                <tr style="font-size:12px">
                  <td><?php echo $quantity;?></td>
                  <td><?php echo $pack; ?></td>
                  <td><?php echo productName($product_id); ?></td>
                  <td><?php echo $productDetails['mfg']; ?></td>
                  <td><?php echo $productDetails['batch']; ?></td>
                  <td><?php echo $stockDetails['exp_date'];?></td>
                  <td><?php echo $tax['vat']; ?> %</td>
                  <td><?php echo $tax['dis']; ?> %</td>
                  <td><?php echo $productDetails['mrp']; ?></td>
                  <td><?php echo $sale_rate; ?></td>
                  <td><?php echo $amount; ?></td>
                </tr>
                 <?php $i++; } ?>           
    
<!--              <tr><td height="200px">&nbsp;</td></tr>                        
-->            </table>
      </div>
        
      <div class="bill-total">
            <table style=" border-collapse:collapse; border:1px #333 solid; text-align:center" align="center" width="100%">
                <tr style="font-size:14px">
                    <th style="border-bottom:#333 dotted 1px;" width="10%">CLASS </th>
                    <th style="border-bottom:#333 dotted 1px;" width="20%">GROSS AMT. </th>
                    <th style="border-bottom:#333 dotted 1px;" width="10%">DISC </th>
                    <th style="border-bottom:#333 dotted 1px;" width="10%">SCM </th>
                    <th style="border-bottom:#333 dotted 1px;" width="20%">Taxable</th>
                    <th style="border-bottom:#333 dotted 1px;" width="10%">VAT</th>
                    <th style="border-bottom:#333 dotted 1px;" width="20%">TOTAL</th>
                </tr>
  
                <?php
$query="SELECT * FROM `order` where id=".$_GET['id'];
$result=mysql_query($query) or die($query);
$row=mysql_fetch_array($result);
$tax=explode(',',$row['tax']);
$tax1=array_unique($tax);
$finalGT=0;
for($i=0;$i<count($tax1);$i++){
		$query1="select sum(amount) from `$tablename` WHERE order_id=".$_GET['id']." AND tax=".$tax1[$i];
		$result1=mysql_query($query1) or die(mysql_error());
		$row1=mysql_fetch_array($result1);
		
		$orderData=tax($tax1[$i]);
	
	$total = $row1[0];
	$discount=($row1[0]*$orderData['dis'])/100;
	$taxable=$total-$discount;
	$vat=($taxable*$orderData['vat'])/100;
	$grandTotal=$taxable+$vat;
	$finalGT=$finalGT+$grandTotal;
?>
					<tr style='font-size:12px;'>
						<td  align='center'> VAT <?php echo $orderData['vat']; ?> %</td>
						<td  align='center'> <?php echo round($total,2); ?> </td>
						<td  align='center'> <?php echo round($discount,2);  ?> </td>
						<td  align='center'>  0.00 </td>
						<td  align='center'> <?php echo round($taxable,2); ?></td>
						<td  align='center'>  <?php echo round($vat,2);?></td>
						<td  align='center'> <?php echo round($grandTotal,2); ?> </td>
					</tr>
<?php } ?>	
                <tr><td style="border-top:1px dotted #333; font-size:14px; text-align:left; text-transform:capitalize" colspan="3"> &nbsp;&nbsp;RUPEES <strong><?php echo ":".convertNum(round($finalGT));?></strong></td>
                <td colspan="2" style="border-top:1px dotted #333; font-size:14px; text-align:left; text-transform:capitalize">NET AMOUNT <strong><?php echo "&nbsp;:&nbsp;Rs. ".round($finalGT,2);?></strong></td>
                <td colspan="2" style="border-top:1px dotted #333; font-size:14px; text-align:left; text-transform:capitalize">PARTY AMOUNT <strong><?php echo "&nbsp;:&nbsp;Rs. ".round($finalGT);?></strong></td></tr>
                <tr><td>&nbsp;</td></tr>
                <tr><td style="border-top:1px solid #333; font-size:12px; text-align:left;" colspan="7"><strong> &nbsp;&nbsp;E.&nbsp;.O.E</strong> : Goods once sold will not be taken back... CHQ RETURN CHARGES Rs.250/- EXTRA</td></tr>
                <tr>
                	<td style="border-top:1px solid #333;font-size:12px; text-align:left;" colspan="3">
                     &nbsp;&nbsp;All Disputes subject to DELHI Jurisdication only.
                    </td>
                    <td colspan="2" style="border-top:1px solid #333; font-size:12px;">( Computer Generated Invoice )</td>
                    <td colspan="2">For <strong>ARADHANA PHARMA</strong></td>
                </tr>
            </table>
        </div>

        </div>
      </div>
  </div>
</body>
</html>	