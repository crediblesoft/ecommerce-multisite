<?php
$tablename="order";
$pagename='order.php';
include('connection.php');
	if(isset($_POST['add'])){
	@extract($_POST);
			$product_id=implode(',',$product_id);
			$sale_rate=implode(',',$sale_rate);
			$quantity=implode(',',$quantity);
			$pack=implode(',',$pack);
			$tax=implode(',',$tax);
			//var_dump($tax);exit;
		//$query="INSERT INTO $tablename SET product_id='".$product_id."',sale_rate='".$sale_rate."',quantity='".$quantity."',customer_id='".$customer_id."',date='".$date."'";
		$query="INSERT INTO `order`(`id`, `product_id`, `sale_rate`, `quantity`, `pack`, `customer_id`, `date`,`tax`) VALUES 
		('','".$product_id."','".$sale_rate."','".$quantity."','".$pack."','".$customer_id."','".$date."','".$tax."')";
		$result=mysql_query($query) or die(mysql_error());
		
		
		$query1="SELECT * FROM `$tablename` order by id desc limit 0,1";
		//echo $query1;exit;
		$result1=mysql_query($query1) or die(mysql_error());
		
		if($result1){
			$data=mysql_fetch_array($result1);
			
			$product_id=explode(',',$data['product_id']);
			$sl_rate=explode(',',$data['sale_rate']);
			$quantity=explode(',',$data['quantity']);
			$pack=explode(',',$data['pack']);
			$tax=explode(',',$data['tax']);
			$count=count($product_id);
			$error=array();
			$total_amount=0;
			for($i=0;$i<$count;$i++){
			
				$query2="SELECT * FROM stock_details WHERE product_id='".$product_id[$i]."'";
				$result2=mysql_query($query2) or die(mysql_error());
				$row2=mysql_fetch_array($result2);
				if($row2['quantity'] >= $quantity[$i]){
				
				$stock_quan=$row2['quantity']-$quantity[$i];
				$amount=$sl_rate[$i]*$quantity[$i];
				$total_amount=$total_amount+$amount;
							

							$query4="INSERT INTO `order_details`(`id`, `customer_id`, `order_id`, `product_id`, `sale_rate`, `quantity`, `pack`, `amount`,`tax`)
							VALUES ('',".$customer_id.",".$data['id'].",".$product_id[$i].",".$sl_rate[$i].",".$quantity[$i].",'".$pack[$i]."',".$amount.",'".$tax[$i]."')";
							//echo $query4;exit;
							$result4=mysql_query($query4) or die(mysql_error());
							//echo "thr";exit;
							
							$query3="UPDATE stock_details SET quantity='".$stock_quan."' WHERE id='".$row2['id']."'";  
							$result3=mysql_query($query3) or die(mysql_error());
						
				}else{
					array_push($error,$product_id[$i]);
				}		
				
			}
			
			if($result3 && $result4){
				$query5="INSERT INTO payment SET customer_id=".$customer_id.",order_id=".$data['id'].",amount=".$total_amount.",type='C',type2='S',date=".$date;
				$result5=mysql_query($query5) or die(mysql_error());
			}
			
		}
		
		if($result){
			$abc=implode(' and ',$error);
			$_SESSION['message']=$abc." product are out of stock";
			header("Location:$pagename");
		}
	}
	
	if(isset($_GET['id'])){
		$query="SELECT * FROM $tablename WHERE id=".$_GET['id'];
		$result=mysql_query($query) or die(mysql_error());
		$editdata=mysql_fetch_array($result);
		@extract($editdata);
	}
	
	if(isset($_REQUEST['update'])){
	@extract($_POST);
	//var_dump($_REQUEST);exit;
		$query="UPDATE $tablename SET product_name='".$product_name."',batch='".$batch."',mfg='".$mfg."' WHERE id=".$id;
		$result=mysql_query($query) or die(mysql_error());
		if($result){
			$_SESSION['message']="Update stock Scussesfully!!!";
			header("Location:$pagename");
		}
	}
	
?>
<html>
<head>
<title>:: Billing ::</title>
<link rel="stylesheet" type="text/css" href="style.css" />

<SCRIPT language="javascript">
        function addRow(tableID) {
 
            var table = document.getElementById(tableID);
 
            var rowCount = table.rows.length;
            var row = table.insertRow(rowCount);
 //alert(rowCount);
            var colCount = table.rows[0].cells.length;
 
            for(var i=0; i<colCount; i++) {
 //alert(i);
                var newcell = row.insertCell(i);
 
                newcell.innerHTML = table.rows[0].cells[i].innerHTML;
				//alert(i);
					//alert(newcell.childNodes[0].type);
                switch(newcell.childNodes[0].type) {
                    case "text":
                            //newcell.childNodes[0].value = "";
							if(i==2){
							newcell.childNodes[0].id = "sale_rate"+rowCount;
							}else if(i==3){
							newcell.childNodes[0].id = "quantity"+rowCount;
							}else if(i==4){
							newcell.childNodes[0].id = "avai"+rowCount;
							}else if(i==5){
							newcell.childNodes[0].id = "pack"+rowCount;
							}
                            break;
					case "hidden":
							if(i==1){
							newcell.childNodes[0].id = "id"+rowCount;
							}else  if(i==7){
							newcell.childNodes[0].id = "Ntax"+rowCount;
							}
							break;
                    case "checkbox":
                            newcell.childNodes[0].checked = false;
                            break;
                    case "select-one":
                            newcell.childNodes[0].selectedIndex = 0;
                            break;
					default :
						if(i==6){
							newcell.childNodes[1].id="tax"+rowCount;
						}else if(i==0){
						newcell.childNodes[1].id = rowCount;
						}
                }
            }
        }
 
        function deleteRow(tableID) {
            try {
            var table = document.getElementById(tableID);
            var rowCount = table.rows.length;
 //alert(rowCount);
            for(var i=0; i<rowCount; i++) {
                var row = table.rows[i];
				//alert(row.cells.length);
				//alert(row.cells[7].childNodes[0].checked);
                var chkbox = row.cells[8].childNodes[0];
                if(null != chkbox && true == chkbox.checked) {
                    if(rowCount <= 1) {
                        alert("Cannot delete all the rows.");
                        break;
                    }
                    table.deleteRow(i);
                    rowCount--;
                    i--;
                }
 
 
            }
            }catch(e) {
                alert(e);
            }
        }
 
 /*function AllProductName(val,id){
	var xmlhttp;
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	  if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
		alert('response');
	    alert(xmlhttp.responseText);
		var data=xmlhttp.responseText;
		//alert(abc[0]);
		document.getElementById("sugessionbox").value=data;
		// alert("Status is : " + xmlhttp.responseText);
		}
	  }

	xmlhttp.open("GET","rcp.php?queryString="+val,true);
xmlhttp.send();
 }*/
 
 
 function ProductList1(val,id){
 //alert(val);
 var val1=val.split("|");
	var xmlhttp;
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	  if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
		//alert('response');
	    //alert(xmlhttp.responseText);
		var data=xmlhttp.responseText;
		//alert(data);
		//alert(id);
		var abc=data.split("|");
		//alert(abc[0]);
		document.getElementById('sugessionbox').style.display='none';
		document.getElementById(id).value=val1[0];
		document.getElementById("id"+id).value=val1[1];
		document.getElementById("sale_rate"+id).value=abc[0];
		document.getElementById("avai"+id).value=abc[1];
		document.getElementById("pack"+id).value=abc[2];
		document.getElementById("tax"+id).value=abc[3]; 
		document.getElementById("Ntax"+id).value=abc[3]; 
		// alert("Status is : " + xmlhttp.responseText);
		}
	  }
     
	xmlhttp.open("GET","show_price.php?pro_id="+val1[1],true);
xmlhttp.send();
 }
    </SCRIPT>
	
	
	 <script type="text/javascript" src="jquery-1.2.1.pack.js"></script>
				<script type="text/javascript">
                    function AllProductName1(val,id){
					//alert('hello');
                        if(val.length == 0) {
                            // Hide the suggestion box.
                            $('#sugessionbox').hide();
                        } else {
							var data=val+'|'+id;
                            $.post("rpc.php", {queryString: ""+data+""}, function(data){
                                if(data.length >0) {
									$("#sugessionbox").empty()
                                    $('#sugessionbox').show();
									//alert(data);
                                    $('#sugessionbox').html(data);
                                }
                            });
                        }
                    } // lookup
                    
                    function fill(val,id,id1) {
					alert(val);
					alert(id);
					alert(id1);
                        $('#inputString').val(thisValue);
                        setTimeout("$('#suggestions').hide();", 200);
                    }
                </script>

</head>
<body>
	<div id='container'>
	<div id='header'>
		<?php include("header.php");?>
     </div>
     <div id='content'>	
	 <div class='title'> <a href='<?php echo $pagename;?>'>Manage Order</a></div>
	 <div class='line'></div>
		<div id='form1'>
		<?php if(isset($_GET['id'])){ ?>
		<form name='product' action='#' method='post'>
		<input type='hidden' name='id' id='id' value='<?php echo $id; ?>'>
			<table class="pro" width="100%">
				<tr>
				<td class='message'><?php if(isset($_SESSION['message'])){ 
						 echo $_SESSION['message'];
					     //unset($_SESSION['message']);
				} ?></td>
				</tr>
				<tr>
				<td>Select Customer</td>
				<td>
				<?php 
						$query="SELECT * FROM customer";
						$result=mysql_query($query) or die(mysql_error());
					?>
					<select name='product_id' class='select_box'>
						<option value=''>---Please Select---</option>
						<?php while($row=mysql_fetch_array($result)){ ?>
						<option value='<?php echo $row['id']; ?>'><?php echo $row['customer_name']; ?></option>
						<?php } ?>
					</select>
				
				</td>
				</tr>
				<tr>
				<th>Select Product</th>
				<th>Sale Rate</th>
				<th>Quantity</th>
				</tr>
				<tr>
				<td>
					<?php 
						$query="SELECT * FROM product";
						$result=mysql_query($query) or die(mysql_error());
					?>
					<select name='product_id' class='select_box'>
						<option value=''>---Please Select---</option>
						<?php while($row=mysql_fetch_array($result)){ ?>
						<option value='<?php echo $row['id']; ?>'><?php echo $row['product_name']; ?></option>
						<?php } ?>
					</select>
				</td>
				<td><input type='text' name='sl_rate' id='sale_rate' class='textbox'></td>
				<td><input type='text' name='quantity' id='quantity' class='textbox'></td>
				</tr>
				<tr>
				<td colspan='2' align='center'><input type='submit' name='update' value='Update' id='submit' class='submit'></td>
				</tr>
			</table>
		</form>
		
		<?php }else{ ?>
		<form name='stock' action='#' method='post'>
			<table align='center' class="pro" width="100%">
				<tr>
				<td class='message'><?php if(isset($_SESSION['message'])){ 
						 echo $_SESSION['message'];
					     //unset($_SESSION['message']);
				} ?></td>
				</tr>
				<tr>
                    <td style="color:#333">Select Customer</td>
                    <td>
                    <?php 
                            $query="SELECT * FROM customer";
                            $result=mysql_query($query) or die(mysql_error());
                        ?>
                        <select name='customer_id' class='select_box'>
                            <option value=''>---Please Select---</option>
                            <?php while($row=mysql_fetch_array($result)){ ?>
                            <option value='<?php echo $row['id']; ?>'><?php echo $row['customer_name']; ?></option>
                            <?php } ?>
                        </select>
                    
                    </td>
                    <td style="color:#333">Date</td>
                    <td> <input type='text' name='date' value="<?php echo date("d-m-Y");?>" id='date' class='textbox'>  </td>
				</tr>
				</tr><td colspan="7"><hr></td>
				<tr>
				<th width="225px">Select Product</th>
				<th width="50px">Sale Rate</th>
				<th width="180px">Order Quantity</th>
				<th width="180px">Available Quantity</th>
				<th width="112px">Pack</th>
				<th width="180px">VAT/Discount</th>
				</tr>

				<tr>
				<td colspan='7'>
				<table id="dataTable" width='100%'>
				<tr>
               
                    <td width="20%">
						<input type='text' name='pp' class='textbox' id='0' onKeyup='AllProductName1(this.value,this.id);'>
                    </td>
					<td><input type='hidden' name='product_id[]' class='textbox' id='id0'> </td>
                    <td width="10%"><input type='text' name='sale_rate[]' id='sale_rate0' class='textbox'></td>
                    <td width="10%"><input type='text' name='quantity[]' id='quantity0' class='textbox'></td>
                    <td width="10%"><input type='text' name='availablequan[]' id='avai0' class='textbox' readonly ></td>
					<td width="20%"><input type='text' name='pack[]' id='pack0' class='textbox' readonly ></td>
					<td width="10%">
					
                        <?php 
                            $query="SELECT * FROM tax";
                            $result=mysql_query($query) or die(mysql_error());
                        ?>
                        <select style="width:150px;" type='select-one' class='select_box' id='tax0' disabled>
                            <option value=''>---VAT/DIS---</option>
                            <?php while($row=mysql_fetch_array($result)){ ?>
                            <option value='<?php echo $row['id']; ?>' ><?php echo $row['vat'].'/'.$row['dis']; ?></option>
                            <?php } ?>
                        </select>
						
                    </td>
					<td width="5%"><input type='hidden' id='Ntax0' name='tax[]'></td>
					 <td><INPUT style="width:50px" type="checkbox" name="chk"/></td>
					</tr>
					</table>
					</td>
				</tr>	
                <tr><td height="50px">&nbsp;</td></tr>
				<tr>
      			<td><input type="button" value="Add Row" onClick="addRow('dataTable')" /></td>
				<td colspan='2' align='center'><input type='submit' name='add' value='Save' id='submit' class='submit'></td>
      			<td><input type="button" value="Delete Row" onClick="deleteRow('dataTable')" /></td>
				</tr>
                <tr><td height="200px">&nbsp;</td></tr>
			</table>
		</form>
		
		<ul id='sugessionbox'></ul>
		<?php } ?>
		</div>
		
     </div>	
	 <div id='footer'>	
     </div>
	 </div>
</body>
</html>