
<div id='head'>
	<div class="logo"><img src="images/logo.png" /><h3>Aradhana Pharma</h3><br /><h5 align="right">( Pharmaceutical Distributor )</h5></div>
	<div class="headcontact">
    	 <p><img src="images/phone-39-256.png" />: +91-8802975705, +91-9958457571</p>
        <img src="images/contact-email.png" /> <p>: aradhanapharma@gmail.com</p>
    </div>
</div>




    <link type="text/css" href="css/menu.css" rel="stylesheet" />
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/js.js"></script>


 <script type="text/javascript">
$(document).ready(function(){
$("body div:last").remove();
});
</script>

<div id="menu">
    <ul class="menu">
        <li><a href='welcome.php'>DashBord</a></li>
        <li><a href='product.php'>Manage Product</a></li>
        <li><a href='customer.php'>Manage Customer</a></li>
        <li><a href='#'class="parent"><span>Manage Stock</span></a>
                <ul>
                    <li><a href='stock.php'>Add Stock</a></li>
                    <li><a href='stockdetails.php'>Show Stock</a></li>
                </ul>
        </li>
        <li><a href='#'class="parent"><span>Order</span></a>
                <ul>
                    <li><a href='order.php'>Add Order</a></li>
                    <li><a href='orderdetails.php'>Show Order</a></li>
                </ul>
        </li>
        <li><a href='payment.php'>Manage Payment</a></li>
	  <li><a href='tax.php'>Manage Tax</a></li>
        <li class="last"><a href='ledger.php'>Manage Ledger</a></li>
    </ul>
</div>
