<?php
$tablename="product";
$pagename='product.php';
include('connection.php');
	if(isset($_REQUEST['add'])){
	@extract($_POST);
	//var_dump($_REQUEST);exit;
		$query="INSERT INTO $tablename SET product_name='".$product_name."', batch='".$batch."', mfg='".$mfg."', mrp='".$mrp."',tax=".$tax;
		$result=mysql_query($query) or die(mysql_error());
		if($result){
			$_SESSION['message']="Add Product Successfully!!!";
			header("Location:$pagename");
		}
	}
	
	if(isset($_GET['id'])){
		$query="SELECT * FROM $tablename WHERE id=".$_GET['id'];
		$result=mysql_query($query) or die(mysql_error());
		$editdata=mysql_fetch_array($result);
		@extract($editdata);
	}

	if(isset($_REQUEST['update'])){
	@extract($_POST);
	//var_dump($_REQUEST);exit;
		$query="UPDATE $tablename SET product_name='".$product_name."',batch='".$batch."',mfg='".$mfg."',mrp='".$mrp."',tax=".$tax." WHERE id=".$id;
		$result=mysql_query($query) or die(mysql_error());
		if($result){
			$_SESSION['message']="Update Customer Scussesfully!!!";
			header("Location:$pagename");
		}
	}

	
	$pagesize=20;
	$query="select count(*) from $tablename";
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	$count=$row[0];
	$page=ceil($count/$pagesize);
	
	if(isset($_GET['page'])){
		$from=($_GET['page']-1)*$pagesize;
		$query="SELECT * FROM $tablename Limit $from,$pagesize";
	}else{
		$query="SELECT * FROM $tablename Limit 0,$pagesize";
	}
		$data=mysql_query($query);
?>
<html>
<head>
<title>:: Billing ::</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
	<div id='container'>
	<div id='header'>
		<?php include("header.php");?>
     </div>
     <div id='content'>	
	 <div class='title'> <a href='<?php echo $pagename;?>'>Manage Product</a></div>
	 <div class='line'></div>
		<div id='form'>
		<?php if(isset($_GET['id'])){ ?>
		<form name='product' action='#' method='post'>
		<input type='hidden' name='id' id='id' value='<?php echo $id; ?>'>
			<table>
				<tr>
				<td class='message'><?php if(isset($_SESSION['message'])){ 
						 echo $_SESSION['message'];
					     //unset($_SESSION['message']);
				} ?></td>
				</tr>
				<tr>
				<td class='form_td'>Product Name</td>
				<td><input type='text' name='product_name' id='product_name' class='textbox' value='<?php echo $product_name; ?>'></td>
				</tr>
				<tr>
				<td class='form_td'>Batch</td>
				<td><input type='text' name='batch' id='batch' class='textbox' value='<?php echo $batch; ?>'></td>
				</tr>
				<tr>
				<td class='form_td'>MFG/MKT.</td>
				<td><input type='text' name='mfg' id='mfg' class='textbox' value='<?php echo $mfg; ?>'></td>
				</tr>
				<tr>
				<td class='form_td'>MRP</td>
				<td><input type='text' name='mrp' id='mrp' class='textbox' value='<?php echo $mrp; ?>'></td>
				</tr>
				
				<tr>
					<td class='form_td'>Select Tax</td>
					<td>
                        <?php 
                            $query="SELECT * FROM tax";
                            $result=mysql_query($query) or die(mysql_error());
                        ?>
                        <select type='select-one' class='select_box' name='tax' id='0'>
                            <option value=''>---Please Select---</option>
                            <?php while($row=mysql_fetch_array($result)){ ?>
                            <option value='<?php echo $row['id']; ?>' <?php if($tax==$row['id']){echo "selected";}?>><?php echo $row['vat'].'/'.$row['dis']; ?></option>
                            <?php } ?>
                        </select>
                    </td>
				</tr>
				<tr>
				<td colspan='2' align='center'><input type='submit' name='update' value='Update' id='submit' class='submit'></td>
				</tr>
			</table>
		</form>
		
		<?php }else{ ?>
		<form name='product' action='#' method='post'>
			<table>
				<tr>
				<td class='message'><?php if(isset($_SESSION['message'])){ 
						 echo $_SESSION['message'];
					     //unset($_SESSION['message']);
				} ?></td>
				</tr>
				<tr>
				<td class='form_td'>Product Name</td>
				<td><input type='text' name='product_name' id='product_name' class='textbox'></td>
				</tr>
				<tr>
				<td class='form_td'>Batch</td>
				<td><input type='text' name='batch' id='batch' class='textbox'></td>
				</tr>
				<tr>
				<td class='form_td'>MFG/MKT.</td>
				<td><input type='text' name='mfg' id='mfg' class='textbox'></td>
				</tr>
				<tr>
				<td class='form_td'>MRP</td>
				<td><input type='text' name='mrp' id='mrp' class='textbox'></td>
				</tr>
				<tr>
					<td class='form_td'>Select Tax</td>
					<td>
                        <?php 
                            $query="SELECT * FROM tax";
                            $result=mysql_query($query) or die(mysql_error());
                        ?>
                        <select type='select-one' class='select_box' name='tax' id='0'>
                            <option value=''>---Please Select---</option>
                            <?php while($row=mysql_fetch_array($result)){ ?>
                            <option value='<?php echo $row['id']; ?>'><?php echo $row['vat'].'/'.$row['dis']; ?></option>
                            <?php } ?>
                        </select>
                    </td>
				</tr>
				<tr>
				<td colspan='2' align='center'><input type='submit' name='add' value='Save' id='submit' class='submit'></td>
				</tr>
			</table>
		</form>
		<?php } ?>
		</div>
		<div id='alldata'>
			<form name='data' >
				<table class="pro" width="100%" cellpadding='2' cellspacing='0' border='0'>
					<tr>
						<th width='10%'>S.No</th>
						<th width='30%'>Product Name</th>
						<th width='20%'>Batch</th>
						<th width='10%'>MFG/MKT.</th>
						<th width='10%'>MRP</th>
						<th width='20%'>&nbsp;</th>
<!--						<th width='30%'><input type='checkbox' ></th>
-->					</tr>
					<?php
						$i=1;
						while($row=mysql_fetch_array($data)){
						@extract($row);
						if($i%2==1){
						   $color='#888';
						}else{
						  $color='#666';
						}
					?>
					<tr bgcolor='<?php echo $color; ?>'>
						<td><?php echo $i; ?></td>
						<td><?php echo $product_name; ?></td>
						<td><?php echo $batch; ?></td>
						<td><?php echo $mfg; ?></td>
						<td><?php echo $mrp; ?></td>
						<td><a href='<?php echo $pagename; ?>?id=<?php echo $id; ?>'> <img src="images/edit_button.png"> </a></td>
<!--						<td><input type='checkbox' name='id[]' value='<?php /*echo $id;*/ ?>' ></td>
-->					</tr>
					<?php $i++; } ?>
					<tr bgcolor='#000'>
						<td colspan='8' align='right' class='pagination'> 
							<?php for($p=1;$p<=$page;$p++){ ?>
								<a href='<?php echo $pagename; ?>?page=<?php echo $p; ?>'> <?php echo $p; ?> </a> 
							<?php } ?> 
						</td>
					</tr>
				</table>
			</form>	
			</div>
     </div>	
	 <div id='footer'>	
     </div>
	 </div>
</body>
</html>