<?php
$tablename="stock";
$pagename='stock.php';
include('connection.php');
	if(isset($_POST['add'])){
	@extract($_POST);
			$product_id=implode(',',$product_id);
			$pur_rate=implode(',',$pur_rate);
			$sale_rate=implode(',',$sale_rate);
			$quantity=implode(',',$quantity);
			$pack=implode(',',$pack);
			$exp_date=implode(',',$exp_date);
		$query="INSERT INTO $tablename SET product_id='".$product_id."',pur_rate='".$pur_rate."',sale_rate='".$sale_rate."',quantity='".$quantity."',pack='".$pack."',exp_date='".$exp_date."',date='".$date."'";
		$result=mysql_query($query) or die(mysql_error());
		
		
		$query1="SELECT * FROM $tablename order by id desc limit 0,1";
		$result1=mysql_query($query1) or die(mysql_error());
		
		if($result1){
			$data=mysql_fetch_array($result1);
			
			$product_id=explode(',',$data['product_id']);
			$pur_rate=explode(',',$data['pur_rate']);
			$sale_rate=explode(',',$data['sale_rate']);
			$quantity=explode(',',$data['quantity']);
			$pack=explode(',',$data['pack']);
			$exp_date=explode(',',$data['exp_date']);
			
			$count=count($product_id);
			
			for($i=0;$i<$count;$i++){
			
				$query2="SELECT * FROM stock_details WHERE product_id='".$product_id[$i]."'";
				$result2=mysql_query($query2) or die(mysql_error());
				$no=mysql_num_rows($result2);
					if($no > 0){
						$row2=mysql_fetch_array($result2);
						$new_quan=$row2['quantity']+$quantity[$i];
						
						$query3="UPDATE stock_details SET stock_id='".$data['id']."',pur_rate='".$pur_rate[$i]."',sale_rate='".$sale_rate[$i]."',quantity='".$new_quan."',pack='".$pack[$i]."',exp_date='".$exp_date[$i]."' WHERE id='".$row2['id']."'";  
						$result3=mysql_query($query3) or die(mysql_error());
						
					}else{
					
						$query4="INSERT INTO stock_details SET stock_id='".$data['id']."',product_id='".$product_id[$i]."',pur_rate='".$pur_rate[$i]."',sale_rate='".$sale_rate[$i]."',quantity='".$quantity[$i]."',pack='".$pack[$i]."',exp_date='".$exp_date[$i]."'";
						$result4=mysql_query($query4) or die(mysql_error());
					}	
				
			}
			
		}
		
		if($result){
			$_SESSION['message']="Add stock Scussesfully!!!";
			header("Location:$pagename");
		}
	}
	
	if(isset($_GET['id'])){
		$query="SELECT * FROM $tablename WHERE id=".$_GET['id'];
		$result=mysql_query($query) or die(mysql_error());
		$editdata=mysql_fetch_array($result);
		@extract($editdata);
	}
	
	if(isset($_REQUEST['update'])){
	@extract($_POST);
	//var_dump($_REQUEST);exit;
		$query="UPDATE $tablename SET product_name='".$product_name."',batch='".$batch."',mfg='".$mfg."' WHERE id=".$id;
		$result=mysql_query($query) or die(mysql_error());
		if($result){
			$_SESSION['message']="Update stock Scussesfully!!!";
			header("Location:$pagename");
		}
	}
	
?>
<html>
<head>
<title>:: Billing ::</title>
<link rel="stylesheet" type="text/css" href="style.css" />

<SCRIPT language="javascript">
        function addRow(tableID) {
 
            var table = document.getElementById(tableID);
 
            var rowCount = table.rows.length;
            var row = table.insertRow(rowCount);
 
            var colCount = table.rows[0].cells.length;
 
            for(var i=0; i<colCount; i++) {
 
                var newcell = row.insertCell(i);
 
                newcell.innerHTML = table.rows[0].cells[i].innerHTML;
                //alert(newcell.childNodes);
                switch(newcell.childNodes[0].type) {
                    case "text":
                            newcell.childNodes[0].value = "";
                            break;
                    case "checkbox":
                            newcell.childNodes[0].checked = false;
                            break;
                    case "select-one":
                            newcell.childNodes[0].selectedIndex = 0;
                            break;
                }
            }
        }
 
        function deleteRow(tableID) {
            try {
            var table = document.getElementById(tableID);
            var rowCount = table.rows.length;
 
            for(var i=0; i<rowCount; i++) {
                var row = table.rows[i];
                var chkbox = row.cells[0].childNodes[0];
                if(null != chkbox && true == chkbox.checked) {
                    if(rowCount <= 1) {
                        alert("Cannot delete all the rows.");
                        break;
                    }
                    table.deleteRow(i);
                    rowCount--;
                    i--;
                }
 
 
            }
            }catch(e) {
                alert(e);
            }
        }
 
    </SCRIPT>

</head>
<body>
	<div id='container'>
	<div id='header'>
		<?php include("header.php");?>
     </div>
     <div id='content'>	
	 <div class='title'> <a href='<?php echo $pagename;?>'>Manage Stock</a></div>
	 <div class='line'></div>
		<div id='form1'>
		<?php if(isset($_GET['id'])){ ?>
		<form name='product' action='#' method='post'>
		<input type='hidden' name='id' id='id' value='<?php echo $id; ?>'>
			<table class="pro">
				<tr>
				<td colspan="5" align="center" class='message'><?php if(isset($_SESSION['message'])){ 
						 echo $_SESSION['message'];
					     //unset($_SESSION['message']);
				} ?></td>
				</tr>
				<tr>
                    <th width="20%">Select Product</th>
                    <th width="20%">Purchase Rate</th>
                    <th width="20%">Sale Rate</th>
                    <th width="20%">Quantity</th>
                    <th width="20%">Exp Date</th>
				</tr>
				<tr>
                    <td>
                        <?php 
                            $query="SELECT * FROM product";
                            $result=mysql_query($query) or die(mysql_error());
                        ?>
                        <select name='product_id' class='select_box'>
                            <option value=''>---Please Select---</option>
                            <?php while($row=mysql_fetch_array($result)){ ?>
                            <option value='<?php echo $row['id']; ?>'><?php echo $row['product_name']; ?></option>
                            <?php } ?>
                        </select>
                    </td>
                    <td><input type='text' name='pur_rate' id='pur_rate' class='textbox'></td>
                    <td><input type='text' name='sl_rate' id='sale_rate' class='textbox'></td>
                    <td><input type='text' name='quantity' id='quantity' class='textbox'></td>
                    <td><input type='text' name='exp_date' id='exp_date' class='textbox'></td>
				</tr>
				<tr>
				<td colspan='5' align='center'><input type='submit' name='update' value='Update' id='submit' class='submit'></td>
				</tr>
			</table>
		</form>
		
		<?php }else{ ?>
		<form name='stock' action='#' method='post'>
			<table class="pro">
				<tr>
				<td class='message'><?php if(isset($_SESSION['message'])){ 
						 echo $_SESSION['message'];
					     //unset($_SESSION['message']);
				} ?></td>
				</tr>
				<tr><td colspan="4">&nbsp;</td>
				<td style="color:#333"> DATE : <input type='text' value="<?php echo date("d-m-Y");?>" name='date' id='date' placeholder='YYYY-MM-DD' class='textbox'>  </td>
				</tr>
				<tr>
                    <th width="20%">Select Product</th>
                    <th width="20%">Purchase Rate</th>
                    <th width="10%">Sale Rate</th>
                    <th width="10%">Quantity</th>
					<th width="10%">Pack</th>
                    <th width="20%">Exp Date</th>
				</tr>
				<tr>
				<td colspan='6'>
				<table width="100%" id="dataTable">
				<tr>
				<td>
					<?php 
						$query="SELECT * FROM product";
						$result=mysql_query($query) or die(mysql_error());
					?>
					<select name='product_id[]' class='select_box'>
						<option value=''>---Please Select---</option>
						<?php while($row=mysql_fetch_array($result)){ ?>
						<option value='<?php echo $row['id']; ?>'><?php echo $row['product_name']; ?></option>
						<?php } ?>
					</select>
				</td>
				<td><input type='text' name='pur_rate[]' id='pur_rate' class='textbox'></td>
				<td><input type='text' name='sale_rate[]' id='sale_rate' class='textbox'></td>
				<td><input type='text' name='quantity[]' id='quantity' class='textbox'></td>
				<td><input type='text' name='pack[]' id='pack' class='textbox'></td>
				<td><input type='text' name='exp_date[]' id='exp_date' class='textbox' placeholder='YYYY-MM'></td>
				</tr>
				</table>
				</td>
				</tr>
					
				<tr>
				<td colspan='5' align='center'><input type='submit' name='add' value='Save' id='submit' class='submit'></td>
				</tr>
			</table>
			
			<INPUT type="button" value="Add Row" onClick="addRow('dataTable')" />
		</form>
		<?php } ?>
		</div>
		
     </div>	
	 <div id='footer'>	
     </div>
	 </div>
</body>
</html>