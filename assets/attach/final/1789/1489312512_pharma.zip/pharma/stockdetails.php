<?php 
$tablename="stock_details";
$pagename='stockdetails.php';
include('connection.php');
include('function.php');
	$pagesize=20;
	$query="select count(*) from $tablename";
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	$count=$row[0];
	$page=ceil($count/$pagesize);
	
	if(isset($_GET['page'])){
		$from=($_GET['page']-1)*$pagesize;
		$query="SELECT * FROM $tablename Limit $from,$pagesize";
	}else{
		$query="SELECT * FROM $tablename Limit 0,$pagesize";
	}
		$data=mysql_query($query);
		
		
	if(isset($_GET['id'])){
		$query="SELECT * FROM $tablename WHERE id=".$_GET['id'];
		$result=mysql_query($query) or die(mysql_error());
	}	
	
	if(isset($_POST['update'])){
		@extract($_POST);
		$query3="UPDATE `stock_details` SET `pur_rate`='".$pur_rate."',`sale_rate`='".$sl_rate."',`quantity`='".$quantity."',`pack`='".$pack."',`exp_date`='".$exp_date."' WHERE `id`='".$id."'";  
		$result3=mysql_query($query3) or die(mysql_error());
		header("Locaiton:$pagename");
	}
?>
<html>
<head>
<title>:: Billing ::</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
	<div id='container'>
	<div id='header'>
		<?php include("header.php");?>
     </div>
     <div id='content'>	
	 <div class='title'> <a href='<?php echo $pagename;?>'>Stock Detail</a></div>
	 <div class='line'></div>
<div id='alldata' style='margin-top:20px;'>
			
			
			<?php if(isset($_GET['id'])){ 
						$editdata=mysql_fetch_array($result);
						@extract($editdata);
			?>
		<form name='product' action='<?php echo $pagename; ?>' method='post'>
		<input type='hidden' name='id' id='id' value='<?php echo $id; ?>'>
			<table class="pro" width="100%">
				<tr>
				<td class='message'><?php if(isset($_SESSION['message'])){ 
						 echo $_SESSION['message'];
					     //unset($_SESSION['message']);
				} ?></td>
				</tr>
				<tr>
				<!--<th class='form_td'>Select Product</th>-->
				<th class='form_td'>Purchase Rate</th>
				<th class='form_td'>Sale Rate</th>
				<th class='form_td'>Quantity</th>
				<th class='form_td'>Pack</th>
				<th class='form_td'>Exp Date</th>
				</tr>
				<tr>
				<!--<td>
					<?php 
						/*$query="SELECT * FROM product";
						$result=mysql_query($query) or die(mysql_error());
					?>
					<select name='product_id' class='select_box'>
						<option value=''>---Please Select---</option>
						<?php while($row=mysql_fetch_array($result)){ ?>
						<option value='<?php echo $row['id']; ?>' <?php if($row['id']==$product_id){echo "selected";} ?> ><?php echo $row['product_name']; ?></option>
						<?php }*/ ?>
					</select>
				</td>-->
				<td><input type='text' name='pur_rate' id='pur_rate'  value='<?php echo $pur_rate; ?>' class='textbox'></td>
				<td><input type='text' name='sl_rate' id='sale_rate'  value='<?php echo $sale_rate; ?>' class='textbox'></td>
				<td><input type='text' name='quantity' id='quantity'  value='<?php echo $quantity; ?>' class='textbox'></td>
				<td><input type='text' name='pack' id='pack'  value='<?php echo $pack; ?>' class='textbox'></td>
				<td><input type='text' name='exp_date' id='exp_date'  value='<?php echo $exp_date; ?>' class='textbox'></td>
				<td><input type='submit' name='update' value='Update' id='submit' class='submit'></td>
                </tr>
				<tr><td>&nbsp;</td></tr>
			</table>
		</form>
		<?php } ?>


			<form name='data' >
				<table width="100%" class="pro" cellpadding='2' cellspacing='0' border='0'>
					<tr bgcolor='#afafc5'>
						<th width='10%'>S No.</th>
						<th width='30%'>Product Name</th>
						<th width='20%'>Exp. Date</th>
						<th width='10%'>Purchase Rate</th>
						<th width='10%'>Sale Rate</th>
						<th width='10%'>Quantity</th>
						<th width='10%'>Pack</th>
						<th width='10%'>Edit</th>
<!--						<th width='30%'><input type='checkbox' ></th>
-->					</tr>
					<?php
						$i=1;
						while($row=mysql_fetch_array($data)){
						@extract($row);
						if($i%2==1){
						   $color='#888';
						}else{
						  $color='#666';
						}
					?>
					<tr bgcolor='<?php echo $color; ?>'>
						<td><?php echo $i; ?></td>
						<td><?php echo productName($product_id); ?></td>
						<td><?php echo $exp_date; ?></td>
						<td><?php echo $pur_rate; ?></td>
						<td><?php echo $sale_rate; ?></td>
						<td><?php echo $quantity; ?></td>
						<td><?php echo $pack; ?></td>
						<td><a href='<?php echo $pagename; ?>?id=<?php echo $id; ?>'><img src="images/edit_button.png"></a></td>
<!--						<td class='td'><input type='checkbox' name='id[]' value='<?php /*echo $id;*/ ?>' ></td>
-->					</tr>
					<?php $i++; } ?>
					<tr bgcolor='#000'>
						<td colspan='8' align='right' class='pagination'> 
							<?php for($p=1;$p<=$page;$p++){ ?>
								<a href='<?php echo $pagename; ?>?page=<?php echo $p; ?>'> <?php echo $p; ?> </a> 
							<?php } ?> 
						</td>
					</tr>
				</table>
			</form>	
			
			</div>
     </div>	
	 <div id='footer'>	
     </div>
	 </div>
</body>
</html>			