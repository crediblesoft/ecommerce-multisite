<?php 
$tablename="order";
$pagename='orderdetails.php';
include('connection.php');
include('function.php');
	$pagesize=10;
	$query="select count(*) from `$tablename`";
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	$count=$row[0];
	$page=ceil($count/$pagesize);
	
	if(isset($_GET['page'])){
		$from=($_GET['page']-1)*$pagesize;
		$query="SELECT * FROM `$tablename` order by id desc Limit $from,$pagesize";
	}else{
		$query="SELECT * FROM `$tablename` order by id desc Limit 0,$pagesize";
	}
		$data=mysql_query($query);
		
		
?>
<html>
<head>
<title>:: Billing ::</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
	<div id='container'>
	<div id='header'>
		<?php include("header.php");?>
     </div>
     <div id='content'>	
	 <div class='title'> <a href='<?php echo $pagename;?>'>Order Detail</a></div>
	 <div class='line'></div>
<div id='alldata' style='margin-top:20px;'>
			<form name='data' >
				<table class="pro" width="100%" cellpadding='2' cellspacing='0' border='0'>
					<tr bgcolor='#afafc5'>
						<th width='10%'>S No.</th>
						<th width='10%'>Invoice No</th>
						<th width='30%'>Customer Name</th>
						<th width='20%'>Order Date</th>
						<th width='20%'>View</th>
						<!--<th width='30%'><input type='checkbox' ></th>-->
					</tr>
					<?php
						$i=1;
						while($row=mysql_fetch_array($data)){
						@extract($row);
						if($i%2==1){
						   $color='#888';
						}else{
						  $color='#666';
						}
					?>
					<tr bgcolor='<?php echo $color; ?>'>
						<td class='td'><?php echo $i; ?></td>
						<td class='td'><?php echo $id; ?></td>
						<td class='td'><?php echo customerName($customer_id); ?></td>
						<td class='td'><?php echo $date; ?></td>
						<td class='td'><a href='orderview.php?id=<?php echo $id; ?>'> View </a></td>
						<!--<td class='td'><input type='checkbox' name='id[]' value='<?php /*echo $id;*/ ?>' ></td>-->
					</tr>
					<?php $i++; } ?>
				
					<tr bgcolor='#000'>
						<td colspan='5' align='right' class='pagination'> 
							<?php for($p=1;$p<=$page;$p++){ ?>
								<a href='<?php echo $pagename; ?>?page=<?php echo $p; ?>'> <?php echo $p; ?> </a> 
							<?php } ?> 
						</td>
					</tr>
				</table>
			</form>	
			</div>
     </div>	
	 <div id='footer'>	
     </div>
	 </div>
</body>
</html>			