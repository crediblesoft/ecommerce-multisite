<?php
$tablename="payment";
$pagename='payment.php';
include('connection.php');
include('function.php');
	if(isset($_REQUEST['add'])){
	@extract($_POST);
	//var_dump($_REQUEST);exit;
		$query="INSERT INTO $tablename SET customer_id='".$customer_id."',amount='".$amount."',type='C',type2='P',date='".$date."',comment='".$comment."'";
		$result=mysql_query($query) or die(mysql_error());
		if($result){
			$_SESSION['message']="Add Payment Scussesfully!!!";
			header("Location:$pagename");
		}
	}
	
	
	if(isset($_GET['id'])){
		$query="SELECT * FROM $tablename WHERE id=".$_GET['id'];
		$result=mysql_query($query) or die(mysql_error());
		$editdata=mysql_fetch_array($result);
		@extract($editdata);
	}
	
	if(isset($_REQUEST['update'])){
	@extract($_POST);
	//var_dump($_REQUEST);exit;
		$query="UPDATE $tablename SET customer_id='".$customer_id."',amount='".$amount."',date='".$date."',comment='".$comment."' WHERE id=".$id;
		$result=mysql_query($query) or die(mysql_error());
		if($result){
			$_SESSION['message']="Update Payment Scussesfully!!!";
			header("Location:$pagename");
		}
	}
	
	$pagesize=10;
	$query="select count(*) from $tablename WHERE type2='P'";
	$result=mysql_query($query) or die(mysql_error());
	$row=mysql_fetch_array($result);
	$count=$row[0];
	$page=ceil($count/$pagesize);
	
	if(isset($_GET['page'])){
		$from=($_GET['page']-1)*10;
		$query="SELECT * FROM $tablename WHERE type2='P' Limit $from,$pagesize";
	}else{
		$query="SELECT * FROM $tablename WHERE type2='P' Limit 0,$pagesize";
	}
		$data=mysql_query($query);
?>
<html>
<head>
<title>:: Billing ::</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
	<div id='container'>
	
	<div id='header'>
		<?php include("header.php");?>
     </div>
     <div id='content'>	
	 <div class='title'> <a href='<?php echo $pagename;?>'>Manage Payment</a></div>
	 <div class='line'></div>
	 <div id='form'>
	 <?php if(isset($_GET['id'])){ ?>
		<form name='customer' action='#' method='post'>
				<input type='hidden' id='id' name='id' value='<?php echo $id;?>'>
			<table>
				<tr>
				<td class='message'><?php if(isset($_SESSION['message'])){ 
						 echo $_SESSION['message'];
					     //unset($_SESSION['message']);
				} ?></td>
				</tr>
				<tr>
				<td class='form_td'>Customer Name</td>
				<td>
					<?php 
						$query="SELECT * FROM customer";
						$result=mysql_query($query) or die(mysql_error());
					?>
					<select name='customer_id' class='select_box'>
						<option value=''>---Please Select---</option>
						<?php while($row=mysql_fetch_array($result)){ ?>
						<option value='<?php echo $row['id']; ?>' <?php if($customer_id==$row['id']){ echo "selected";} ?> ><?php echo $row['customer_name']; ?></option>
						<?php } ?>
					</select>
				</td>
				</tr>
				<tr>
				<td class='form_td'>Amount</td>
				<td><input type='text' name='amount' id='amount' class='textbox' value='<?php echo $amount?>' /></td>
				</tr>
				<tr>
				<td class='form_td'>Date</td>
				<td><input type='text' name='date' id='date' class='textbox' value='<?php echo $date?>' /></td>
				</tr>
				<tr>
				<td class='form_td'>Comment</td>
				<td><textarea name='comment' id='comment' class='textarea' ><?php echo $comment; ?></textarea></td>
				</tr>
				<tr>
				<td colspan='2' align='center'><input type='submit' name='update' value='Update' id='submit' class='submit'></td>
				</tr>
			</table>
			</form>
			<?php }else{ ?>
			<form name='customer' action='#' method='post'>
			<table>
				<tr>
				<td class='message'><?php if(isset($_SESSION['message'])){ 
						 echo $_SESSION['message'];
					     //unset($_SESSION['message']);
				} ?></td>
				</tr>
				<tr>
				<td class='form_td'>Select Customer</td>
				<td>
					<?php 
						$query="SELECT * FROM customer";
						$result=mysql_query($query) or die(mysql_error());
					?>
					<select name='customer_id' class='select_box'>
						<option value=''>---Please Select---</option>
						<?php while($row=mysql_fetch_array($result)){ ?>
						<option value='<?php echo $row['id']; ?>'><?php echo $row['customer_name']; ?></option>
						<?php } ?>
					</select>
				</td>
				</tr>
				<tr>
				<td class='form_td'>Amount</td>
				<td><input type='text' name='amount' id='amount' class='textbox' /></td>
				</tr>
				<tr>
				<td class='form_td'>Date</td>
				<td><input type='text' name='date' id='date' class='textbox' /></td>
				</tr>
				<tr>
				<td class='form_td'>Comment</td>
				<td><textarea name='comment' id='comment' class='textarea' ></textarea></td>
				</tr>
				<tr>
				<td colspan='2' align='center'><input type='submit' name='add' value='Save' id='submit' class='submit'></td>
				</tr>
			</table>
			</form>		
			<?php } ?>
			</div>
			<div id='alldata'>
			<form name='data' >
				<table class="pro" width="100%" cellpadding='2' cellspacing='0' border='0'>
					<tr bgcolor='#afafc5'>
						<th width='10%'>S No.</th>
						<th width='25%'>Customer Name</th>
						<th width='10%'>Amount</th>
						<th width='10%'>Date</th>
						<th width='35%'>Comment</th>
						<th width='10%'>Edit</th>
<!--						<th width='20%'><input type='checkbox' ></th>
-->					</tr>
					<?php
						$i=1;
						while($row=mysql_fetch_array($data)){
						@extract($row);
						if($i%2==1){
						   $color='#888';
						}else{
						  $color='#666';
						}
					?>
					<tr bgcolor='<?php echo $color; ?>'>
						<td class='td'><?php echo $i; ?></td>
						<td class='td'><?php echo customerName($customer_id); ?></td>
						<td class='td'><?php echo $amount; ?></td>
						<td class='td'><?php echo $date; ?></td>
						<td class='td'><?php echo $comment; ?></td>
						<td class='td'><a href='<?php echo $pagename; ?>?id=<?php echo $id; ?>'>  <img src="images/edit_button.png"> </a></td>
<!--						<td class='td'><input type='checkbox' name='id[]' value='<?php /*echo $id;*/ ?>' ></td>
-->					</tr>
					<?php $i++; } ?>
					<tr bgcolor='#000'>
						<td colspan='6' align='right' class='pagination'> 
							<?php for($p=1;$p<=$page;$p++){ ?>
								<a href='<?php echo $pagename; ?>?page=<?php echo $p; ?>'> <?php echo $p; ?> </a> 
							<?php } ?> 
						</td>
					</tr>
				</table>
			</form>	
			</div>
		
     </div>	
	 <div id='footer'>	
     </div>
	 </div>
</body>
</html>