<?php
include('connection.php');
	if(isset($_REQUEST['submit'])){
		$query="SELECT * FROM profile where username='admin' and password='admin'";
		$result=mysql_query($query);
		$no=mysql_num_rows($result);
		if($no==1){
			$row=mysql_fetch_assoc($result);
			header("Location:welcome.php");
		}
	}
?>
<style>
body{
background:#e1e8eb;
margin:0 auto;
font-family:"HelveticaNeue-Light","Helvetica Neue Light","Helvetica Neue",Helvetica,Arial,"Lucida Grande",sans-serif;
}

#container{
width:1024px;
margin:200px 200px 200px 500px;
}

#content{
width:365px;
height:180px;
box-shadow: 19px 57px 61px #000000;
background: #e1e1e1;
border-radius: 0.4em;
border: 1px solid #e1e1e1;
overflow: hidden;
position: relative;
}

.text{
height:30px;
width:200px;
padding:2px;

}

.td_text{
font-size:15px;
font-weight:bold;
padding:5px 50px 2px 15px;
}

.head{
font-weight:bold;
font-size:20px;
padding:5px 0px 10px 15px;	
}
.submit{
margin:10px 12px 0px 0px;
font-weight:bold;
padding:2px 5px 2px 5px;
}
</style>

<html>
<head>
<title>:: Billing ::</title>
</head>
<body>
     <div id='container'>
	    <div id='content'>
		<form name='login' action='#' method='post'>
	    <table>
		   <tr>
				<td colspan='2' class='head'>ADMIN LOGIN</td>
			</tr>
			<tr>
				<td colspan='2' style='width:365px;border-bottom: 1px solid #fff;'></td>
			</tr>
			<tr>
				<td colspan='2' height='10'></td>
			</tr>
			<tr>
				<td class='td_text'>Username</td>
				<td><input type='text' name='username' class='text' /></td>
			</tr>
			<tr>
				<td class='td_text'>Password</td>
				<td><input type='password' name='password' class='text' /></td>
			</tr>
			<tr>
				<td colspan='2'	align='right'><input type='submit' name='submit' value='Login' class='submit' /></td>
			</tr>
		</table>
		</form>
        </div>		
     </div>
</body>
</html>